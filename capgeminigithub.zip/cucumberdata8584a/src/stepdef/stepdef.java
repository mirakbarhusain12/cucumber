package stepdef;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.gargoylesoftware.css.parser.javacc.ParseException;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
         //throw new PendingException();

     }		
    //user inputs credentials from "a.json"
    @And("^user inputs credentials from \"(.*)\"$")
    public void userinputsusernameandPassword(String path) throws Throwable 							
    {	
    	  Object obj = new JSONParser().parse(new FileReader(path)); 
          
          // typecasting obj to JSONObject 
          JSONObject jo = (JSONObject) obj; 
            
          // getting firstName and lastName 
          String Name = (String) jo.get("Name"); 
          String password = (String) jo.get("password"); 
            
         // System.out.println(firstName); 
          //System.out.println(lastName); 
          d.findElement(By.linkText("Sign In")).click();

    		Thread.sleep(2000);
    		d.findElement(By.xpath("//*[@id='userName']")).sendKeys(Name);
    		d.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
    		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
            
          
          } 
    	
    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    	
    	 
    	System.out.println("welcome");
    	
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
    	 restart:
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password-A defect");
		    }
	      //throw new PendingException();
            
	 }	
    
    
}