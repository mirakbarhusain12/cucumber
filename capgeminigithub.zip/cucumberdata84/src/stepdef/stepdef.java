package stepdef;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
         //throw new PendingException();
     }		
  
     
    @When("^user inputs credentials$")
    public void userinputsusernameandPassword(DataTable dt) throws Throwable 							
    {		
    	List<List<String>> data = dt.raw();

		//This is to get the first data of the set (First Row + First Column)
		//driver.findElement(By.id("log")).sendKeys(data.get(0).get(0)); 

		//This is to get the first data of the set (First Row + Second Column)
	    //driver.findElement(By.id("pwd")).sendKeys(data.get(0).get(1));
    	System.out.println("welcome akbar");
   	System.out.println(data.get(0).get(0));
    	System.out.println(data.get(0).get(1));

    	d.findElement(By.linkText("Sign In")).click();

  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys(data.get(0).get(0));
  		d.findElement(By.xpath("//*[@id='password']")).sendKeys(data.get(0).get(1));
  		
  		
  		//d.findElement(By.xpath("//*[@id='userName']")).sendKeys(name);
  		//d.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        //throw new PendingException();

    }		

    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password-A defect");
		    }
	      //throw new PendingException();

	 }	
    /**
    @When("^user inputs valid \"(.*)\" and invalid \"(.*)\"$")
     public void userinputsusernameandPasswordi(String name, String password) throws Throwable 							
    {		
    	 
    	d.findElement(By.linkText("Sign In")).click();

  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys(name);
  		d.findElement(By.xpath("//*[@id='password']")).sendKeys(password);
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        //throw new PendingException();

    }		
     
    @Then("^Login should fail$")
    public void Login_should_be_fail() throws Throwable 							
    {    		
    	 boolean a1=d.getPageSource().contains("Login incorrect. Please try again");
		    if(a1) 
		    {
		        System.out.println("login not success for valid name  and invalid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and invalid password-A defect");
		    }
	      //throw new PendingException();

	 }		
*/

}