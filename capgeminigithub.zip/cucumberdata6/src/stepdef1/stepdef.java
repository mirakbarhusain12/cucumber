package stepdef1;
import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site1$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
         //throw new PendingException();
     }		
    
 
    @When("^user enters name and password$")
    public void userinputsusernameandPassword() throws Throwable 							
    {		
    	 
                 // System.out.print(name);
                 // System.out.print("  ");
                 // System.out.print(password);
                      
                     d.findElement(By.linkText("Sign In")).click();
                     
                     Thread.sleep(3000);
                     //d.findElement(By.id("userName")).sendKeys(name);
                    // d.findElement(By.id("password")).sendKeys(password);
                     d.findElement(By.id("submitBtn")).click();
                     Thread.sleep(1000);
        
        
        //throw new PendingException();

    }		

    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password-A defect");
		    }
	      //throw new PendingException();

	 }	
    
}