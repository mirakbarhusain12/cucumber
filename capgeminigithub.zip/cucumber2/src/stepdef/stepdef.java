package stepdef;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
        //Thread.sleep(10000);
        //throw new PendingException();
     }		

    @When("user inputs Username and Password$")					
    public void user_inputs_Username_and_Password() throws Throwable 							
    {		
    	d.findElement(By.linkText("Sign In")).click();

  		Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='userName']")).sendKeys("mah@yahoo.com");
  		d.findElement(By.xpath("//*[@id='password']")).sendKeys("mysore15");
  		d.findElement(By.xpath("//*[@id='submitBtn']")).click();
        //throw new PendingException();

    }		

    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success  No defect");

		    }
		    else
		    {
		        System.out.println("login not success  A defect");
		    }
	      //throw new PendingException();

	 }		
    //--------------------------------------------------------
    @Given("^user clicks the link boom a bus$")
    public void user_clicks_the_link_boom_a_bus() throws Throwable 
    {
    	d.findElement(By.linkText("Book a Bus")).click();
       //throw new PendingException();
    }

    @When("^user inputs city name in search field$")
    public void user_inputs_city_name_in_search_field() throws Throwable {
    	d.findElement(By.name("search")).sendKeys("bangalore");
  		//d.findElement(By.xpath("//*[@id=\"gsc-i-id1\"']")).sendKeys("bangalore");

    	//*[@id="gsc-i-id1"] 	
  		d.findElement(By.xpath("//button[@class='gsc-search-button gsc-search-button-v2']")).click();
	  //  throw new PendingException();
    }

    @Then("^user should see a module$")
    public void user_should_see_a_module() throws Throwable 
    {
  		WebElement e1=d.findElement(By.xpath("//div[@class='gsc-results-wrapper-overlay gsc-results-wrapper-visible']"));
	   if(e1.isDisplayed())
	   {
	        System.out.println("on clicking the search button the module appeared- No defect");
	   
	   }
	   else
	   {
	        System.out.println("on clicking the search button the module did not appear- A defect");
	   
	   }
 		//WebElement e11=d.findElement(By.xpath("//div[@class='gsc-results-close-btn gsc-results-close-btn-visible']"));
 		WebDriverWait w1=new WebDriverWait(d,50);
 		WebElement e11=w1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='gsc-results-close-btn gsc-results-close-btn-visible']")));	
 		//d.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
  		e11.click();
 		//d.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
     	//d.findElement(By.linkText("Logout")).click();
  		//	throw new PendingException();
    }

    @Given("^user clicks the link cancel tickets$")
    public void user_clicks_the_link_cancel_tickets() throws Throwable 
    {
  	    Thread.sleep(5000);
    	d.findElement(By.linkText("Cancel Tickets")).click();
        throw new PendingException();
    }

    @Then("^user should see a module for cancelling tickets$")
    public void user_should_see_a_module_for_cancelling_tickets() throws Throwable {
    	 if(d.getPageSource().contains("Cancel Tickets"))
  	   {
  	        System.out.println("on clicking the cancel link module appeared- No defect");
  	   
  	   }
  	   else
  	   {
  	        System.out.println("on clicking the cancel link the module did not appear- A defect");
  	   
  	   }
    	
    	
    	//throw new PendingException();
    }


    //-------------------------------------------------------
    

}