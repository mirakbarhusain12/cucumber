package stepdef;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^google home page is on screen$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	  d=new ChromeDriver();
        d.get("http://www.google.com");
        d.manage().window().maximize();
        //Thread.sleep(10000);
        //throw new PendingException();
     }		

    @When("^user inputs cars$")					
    public void user_inputs_Username_and_Password() throws Throwable 							
    {		
    	d.findElement(By.name("q")).sendKeys("cars" );
  

    }		
    @And("^and user clicks search button$")					
    public void user_clicks_search_button() throws Throwable 							
    {		
    	d.findElement(By.linkText("btnK")).click();
 

    }		
    
    
    

    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Gmail")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password A defect");
		    }
	      //throw new PendingException();

	 }		

}