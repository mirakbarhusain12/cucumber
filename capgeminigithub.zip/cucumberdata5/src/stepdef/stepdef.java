package stepdef;
import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;		
import cucumber.api.java.en.Then;		
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
    @Given("^Open ksrtc web site$")				
    public void Open_ksrtc_web_site() throws Throwable							
    {	
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
    	d=new ChromeDriver();
        d.get("http://www.ksrtc.in/oprs-web/");
        d.manage().window().maximize();
         //throw new PendingException();
     }		
   @When("^user selects name and password from \"(.*)\" Login should be successfull$")
    public void userinputsusernameandPassword(String filepath) throws Throwable 							
    {		
    	File file=new File(filepath);
        FileInputStream fi=new FileInputStream(file);
        //String fn="C:\\Users\\Admin\\Desktop\\Data.xlsx";
        System.out.println(filepath);
        System.out.println("welcome");

        //Find the file extension by splitting file name in substring  and getting only extension name
        String fe=filepath.substring(filepath.indexOf("."));
        System.out.println(fe);
        try
        {
             if(fe.equals(".xlsx"))
           {
               System.out.println("your file extension is xlsx");
              @SuppressWarnings("resource")
			Workbook w = new XSSFWorkbook(fi);
              Sheet guru99Sheet = w.getSheet("s");
              System.out.println("welcome akbar");

              int rowCount = guru99Sheet.getLastRowNum()-guru99Sheet.getFirstRowNum();
              for (int i = 0; i < rowCount+1; i++) 
              {
                  Row row = guru99Sheet.getRow(i);
                  String name=null;
           	   String password=null;
                  for (int j = 0; j < row.getLastCellNum(); j++) 
                  {
                        if(j==0)
                	  {
      
                     	name=row.getCell(j).getStringCellValue();

                	  }
                	if(j==1)
                	{
                	 password=row.getCell(j).getStringCellValue();
                	}
                  }  
   
                  System.out.print(name);
                  System.out.print("  ");
                  System.out.print(password);
                    d.findElement(By.linkText("Sign In")).click();
                    Thread.sleep(3000);
                     d.findElement(By.id("userName")).sendKeys(name);
                     d.findElement(By.id("password")).sendKeys(password);
                     d.findElement(By.id("submitBtn")).click();
                     Thread.sleep(4000);
                     boolean flag1,flag2;
                      	 if(d.findElement(By.linkText("Logout")).isDisplayed()) 
                  	    {
                      		  flag1=true;
                        }
                  	    else
                  	    {
                     		 flag1=false;
    	           	    }
                        if(d.getPageSource().contains("Login incorrect. Please try again")) 
                   	    {
                      		   flag2=true;
                        }
                   	    else
                   	    {
                     		 flag2=false;
                         } 
          Thread.sleep(2000);
                    
                     if(flag1) 
              	    {
               	        System.out.println("login success for valid name  and valid password-No defect");
                    }
              	    else
              	    {
               	        System.out.println("login not success for valid name  and valid password-A defect");
	            	    }
                    if(flag2) 
              	    {
               	        System.out.println("login not success for valid name  and in valid password-No defect");
                    }
              	    else
              	    {
               	        System.out.println("login success for valid name  and in valid password-A defect");
	                }
                   
                       d.findElement(By.linkText("Logout")).click();
                  
        }       
              }
           }
      //for ends------------------------------------------------------------         
   catch (Exception e)
          {
       		throw (e);
          }
  //throw new PendingException();
    }		
/**
    @Then("^Login should be successfull$")					
    public void Login_should_be_successfull() throws Throwable 							
    {    		
    	 boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		    if(a) 
		    {
		        System.out.println("login success for valid name  and valid password-No defect");

		    }
		    else
		    {
		        System.out.println("login not success for valid name  and valid password-A defect");
		    }
	      //throw new PendingException();

	 }	
  */  
}